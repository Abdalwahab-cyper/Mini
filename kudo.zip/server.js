const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

const players = {};

io.on('connection', (socket) => {
  console.log('New player connected:', socket.id);

  socket.on('newPlayer', (data) => {
    players[socket.id] = data;
    io.emit('players', players);
  });

  socket.on('playerUpdate', (data) => {
    players[socket.id] = data;
    io.emit('players', players);
  });

  socket.on('shoot', (data) => {
    socket.broadcast.emit('shoot', data);
  });

  socket.on('disconnect', () => {
    console.log('Player disconnected:', socket.id);
    delete players[socket.id];
    io.emit('playerDisconnected', socket.id);
  });
});

server.listen(3000, () => {
  console.log('Server running on port 3000');
});